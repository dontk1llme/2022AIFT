# Trading_Project
Studying and Updating stock trading programs

키움증권의 주식 (수동,자동)매매 및 내역, 보유종목과 수익률, 급등주 배율 조정, 종목코드별 주가이동평균 추이그래프 제공.

* UI - designer
* Backend - python, DB Browser(SQLite)
